[中文](./README.md) | English

<div align="center">
<img alt="logo" height="120" src="./assets/img/logo/puock.png" width="120"/>
</div>

## Introduction

![cover](./screenshot.png)

<div align="center">
    <h1>WordPress Theme - Puock</h1>
    <p>A high-value adaptive theme based on WordPress, supporting day and night modes.</p>
      <a target="_blank" href="https://github.com/Licoy/wordpress-theme-puock/releases/latest">
        <img src="https://img.shields.io/github/v/release/Licoy/wordpress-theme-puock.svg?logo=git" alt="Release-Version">
      </a>
    <a target="_blank" href="https://github.com/Licoy/wordpress-theme-puock">
        <img src="https://img.shields.io/badge/WordPress-V6.0+-0099CC.svg?logo=wordpress" alt="WordPress-Version">
      </a>
    <a target="_blank" href="https://github.com/Licoy/wordpress-theme-puock">
        <img src="https://img.shields.io/badge/PHP-V7.4+-666699.svg?logo=php" alt="PHP-Version">
      </a>
    <br>
    <a target="_blank" href="https://t.me/puocktheme">
        <img src="https://img.shields.io/badge/TG-@PuockTheme-29a9ec.svg?logo=Telegram" alt="Telegram Group">
      </a>
    <br><br>
    <img src='https://repobeats.axiom.co/api/embed/5f966833712409c00d4269bf2800b2d4762e09ea.svg'></img>
    <br><br>
    <a href="https://www.producthunt.com/posts/puock-wordpress-theme?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-puock-wordpress-theme" target="_blank"><img src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=327798&theme=light" alt="Puock WordPress Theme - A high-value adaptive theme based on WordPress | Product Hunt" style="width: 250px; height: 54px;" width="250" height="54" /></a>
</div>

## Theme options screenshot
![theme-options.png](./.screenshot/options.png)

## Install
Go to [Releases](https://github.com/Licoy/wordpress-theme-puock/releases) and download only the official install package named
`Puock-VX.Y.Z.zip` for the version you want. In WordPress, open "Appearance" → "Themes", click "Add", then upload, install, and enable that package.

**Tip: in order to prevent incompatible themes, please backup data before installing themes to prevent data fields from overlapping.**

**Important: do not clone the repository or download GitHub's automatically generated `Source code (zip)` or `Source code (tar.gz)` files. They are source snapshots, not official install packages.**

### Environmental requirements

- WordPress `6.0+`
- PHP `7.4+`

## Theme characteristics
- [x] Support day and dark mode
- [x] Global load without refresh
- [x] Home “load more”
- [x] Support blog, CMS, enterprise three layouts
- [x] Built-in WP optimization strategy
- [x] Built-in frontend user center
- [x] Support QQ / Github / Gitee / Weibo login
- [x] Rainbow OAuth aggregation login
- [x] Support thumbnail pseudo-static
- [x] Global top scrolling announcements
- [x] Graphics and geetest captcha support
- [x] Custom SMTP support
- [x] All sites are grayed out with one click
- [x] Web page compressed into one line
- [x] Background anti-malicious login
- [x] Auto/follow system color mode
- [x] Great SEO features built in
- [x] Comments ajax loaded
- [x] Reading time & word count
- [x] Article likes, rewards, poster generation, sharing
- [x] Twemoji integration
- [x] Rich ad slots
- [x] Rich widgets
- [x] Automatic Baidu link submission
- [x] Numerous page templates (Reader Wall/Archives/Book Recommendations/Site Navigation/Tags/Sitemap etc.)
- [x] Numerous shortcode support (visible after downloading / commenting / visible after login / visible after login and verification email / multiple prompt boxes / Github cards, etc.)
- [x] Support Dplayer player
- [x] MacOS-like code style and copy code
- [x] High-value background configuration integrated with Vue3+NaiveUI
- [x] Article multi-level directory generation
- [x] Multi-level TOC expansion
- [x] Sidebar sticky scrolling
- [x] Mobile sidebar
- [x] WP cache support
- [x] Custom primary color
- [x] LOGO sweep light animation
- [x] Skeleton loading
- [x] Image/avatar lazy loading
- [x] Frontend login/registration/password reset
- [x] Settings reset
- [x] Third‑party binding in user center
- [x] ChatGPT and AI painting support
- [x] Please refer to the release notes for more feature updates：[releases](https://github.com/Licoy/wordpress-theme-puock/releases)
- [x] More features, waiting for your [proposal](https://github.com/Licoy/wordpress-theme-puock/issues)
## Documentation
- Theme use document: [Use immediately](https://www.licoy.cn/puock-doc.html)
- **Feature Usage Guide: [View Detailed Tutorial](./USAGE_EN.md)** (Detailed instructions for friendship links, alert boxes, and more)
- Issue Feedback: [Submit Issue](https://github.com/Licoy/wordpress-theme-puock/issues)
- Community Group: [Join Group](https://licoy.cn/go/puock-update.php?r=qq_qun)
## Support
- Reward theme to support：[Click me in](https://licoy.cn/puock-theme-sponsor.html)
## Thanks
- [Jetbrains](https://www.jetbrains.com/?from=wordpress-theme-puock)

## License
- [GPL 3.0](./LICENSE)
- Please abide by the open source agreement and keep the author's signature at the bottom of the subject
