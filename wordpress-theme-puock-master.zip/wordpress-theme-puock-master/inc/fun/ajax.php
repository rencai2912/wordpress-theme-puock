<?php

function pk_ajax_url($action, $args = [])
{
    $url = admin_url('admin-ajax.php?action=' . $action);
    if (!empty($args)) {
        $url .= '&' . http_build_query($args);
    }
    return $url;
}

/**
 * @param $name
 * @param $callback callable
 * @param $public
 * @return void
 */
function pk_ajax_register($name, $callback, $public = false)
{
    add_action('wp_ajax_' . $name, $callback);
    if ($public) {
        add_action('wp_ajax_nopriv_' . $name, $callback);
    }
}

function pk_ajax_get_req_body()
{
    $body = @file_get_contents('php://input');
    return json_decode($body, true);
}

function pk_ajax_check_theme_options_nonce()
{
    check_ajax_referer('pk_theme_options', 'nonce');
}

function pk_ajax_result_page($success = true, $info = '', $from_redirect = '')
{
    if ($success && !empty($from_redirect)) {
        wp_redirect($from_redirect);
        exit;
    } else {
        pk_session_call(function () use ($info) {
            $_SESSION['error_info'] = $info;
        });
        wp_redirect(PUOCK_ABS_URI . '/error.php');
        wp_die();
    }
}

function pk_ajax_get_theme_options()
{
    if (current_user_can('edit_theme_options')) {
        wp_send_json_success([
            'settings' => get_option(PUOCK_OPT),
        ]);
    } else {
        wp_send_json_error(__('权限不足', PUOCK));
    }
}

pk_ajax_register('get_theme_options', 'pk_ajax_get_theme_options');

function pk_ajax_update_theme_options()
{
    if (current_user_can('edit_theme_options')) {
        pk_ajax_check_theme_options_nonce();
        $body = pk_ajax_get_req_body();
        update_option(PUOCK_OPT, $body);
        do_action('pk_option_updated', $body);
        flush_rewrite_rules();
        wp_send_json_success();
    } else {
        wp_send_json_error(__('权限不足', PUOCK));
    }
}

pk_ajax_register('update_theme_options', 'pk_ajax_update_theme_options');

/**
 * 获取主题设置默认值
 */
function pk_ajax_get_theme_options_defaults()
{
    if (current_user_can('edit_theme_options')) {
        $setting = new \Puock\Theme\setting\PuockSetting();
        $defaults = $setting->get_default_options();
        wp_send_json_success([
            'defaults' => $defaults,
        ]);
    } else {
        wp_send_json_error(__('权限不足', PUOCK));
    }
}

pk_ajax_register('get_theme_options_defaults', 'pk_ajax_get_theme_options_defaults');

/**
 * 重置主题设置为默认值
 */
function pk_ajax_reset_theme_options()
{
    if (current_user_can('edit_theme_options')) {
        pk_ajax_check_theme_options_nonce();
        $setting = new \Puock\Theme\setting\PuockSetting();
        $defaults = $setting->get_default_options();
        update_option(PUOCK_OPT, $defaults);
        do_action('pk_option_updated', $defaults);
        flush_rewrite_rules();
        wp_send_json_success([
            'message' => __('设置已重置为默认值', PUOCK),
            'data' => $defaults,
        ]);
    } else {
        wp_send_json_error(__('权限不足', PUOCK));
    }
}

pk_ajax_register('reset_theme_options', 'pk_ajax_reset_theme_options');
